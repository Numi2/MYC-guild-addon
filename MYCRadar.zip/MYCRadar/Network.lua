local _, R = ...
R.Net = { queue = {}, lookup = {}, lastSend = 0, errors = 0 }
local N = R.Net

local function chunks(records, maxLength)
    local out, current = {}, ""
    for _, record in ipairs(records) do
        local proposed = current == "" and record or current .. "," .. record
        if #proposed > maxLength and current ~= "" then
            out[#out + 1] = current
            current = record
        else
            current = proposed
        end
    end
    out[#out + 1] = current
    return out
end

function N:Clear()
    self.queue = {}
    self.lookup = {}
    self.lastSend = 0
end

function N:Queue(text, key, priority)
    if not R:IsEnabled() or type(text) ~= "string" or #text > 255 then return end
    key = key or text
    local existing = self.lookup[key]
    if existing then
        existing.text = text
        existing.at = R:Clock()
        return
    end
    if #self.queue >= 90 then
        local dropped = table.remove(self.queue)
        if dropped then self.lookup[dropped.key] = nil end
    end
    local row = { text = text, key = key, at = R:Clock(), tries = 0 }
    if priority then table.insert(self.queue, 1, row) else table.insert(self.queue, row) end
    self.lookup[key] = row
end

function N:QueueSnapshot(kind, records, header, priority)
    -- 170 bytes per payload keeps every packet under the 255-byte addon limit.
    local pages = chunks(records, 170)
    local revision = math.floor(R:Clock() * 1000) % 100000000
    for index, data in ipairs(pages) do
        local text
        if header == "" then
            text = string.format("%s|%d|%d|%d|%s", kind, revision, index, #pages, data)
        else
            text = string.format("%s|%d|%d|%d|%s|%s", kind, revision, index, #pages, header, data)
        end
        self:Queue(text, kind .. ":" .. index, priority)
    end
    -- Replace any obsolete tail packets from an older, larger snapshot.
    for index = #pages + 1, 60 do
        local key = kind .. ":" .. index
        local old = self.lookup[key]
        if old then
            for j = #self.queue, 1, -1 do
                if self.queue[j] == old then table.remove(self.queue, j) end
            end
            self.lookup[key] = nil
        end
    end
end

function N:SendNext()
    if #self.queue == 0 or not R:InGuild() or not R.commReady then return end
    local now = R:Clock()
    if now - self.lastSend < 1.5 then return end
    if not C_ChatInfo or not C_ChatInfo.SendAddonMessage then return end
    local row = self.queue[1]
    if now - row.at > 600 then
        table.remove(self.queue, 1)
        self.lookup[row.key] = nil
        return
    end
    self.lastSend = now
    local ok, outcome = pcall(C_ChatInfo.SendAddonMessage, R.prefix, row.text, "GUILD")
    if ok and (outcome == 0 or outcome == true) then
        table.remove(self.queue, 1)
        self.lookup[row.key] = nil
    else
        row.tries = row.tries + 1
        if row.tries >= 6 then
            table.remove(self.queue, 1)
            self.lookup[row.key] = nil
            self.errors = self.errors + 1
        end
        -- Lockdown/throttle: back off without hammering the addon channel.
        self.lastSend = now + 3
    end
end

local function parseSnapshot(message, kind, numericHeaderFields)
    local revision, index, total, rest = message:match("^" .. kind .. "|(%d+)|(%d+)|(%d+)|(.*)$")
    revision, index, total = tonumber(revision), tonumber(index), tonumber(total)
    if not revision or not index or not total or index < 1 or total < 1 or total > 30 or index > total then return end
    local header, payload
    if numericHeaderFields == 3 then
        local a, b, c, data = rest:match("^(%d+)|(%d+)|(%d+)|([%d,]*)$")
        if not a then return end
        header, payload = { tonumber(a), tonumber(b), tonumber(c) }, data
    else
        payload = rest
        if not payload:match("^[%d:,]*$") then return end
        header = {}
    end
    return revision, index, total, header, payload
end

function N:Receive(message, channel, sender)
    if channel ~= "GUILD" or not R:InGuild() then return end
    if type(message) ~= "string" or #message > 255 or type(sender) ~= "string" or #sender > 75 then return end
    local mine = UnitName and UnitName("player")
    local full, qualifier
    if UnitFullName then
        local ok, name, second = pcall(UnitFullName, "player")
        if ok then full, qualifier = name, second end
    end
    if sender == mine or sender == full or
        (type(full) == "string" and type(qualifier) == "string" and
            (sender == full .. " " .. qualifier or sender == full .. "-" .. qualifier)) or
        (Ambiguate and Ambiguate(sender, "none") == mine) then return end
    local peer = R.peers[sender] or { recipes = {} }
    R.peers[sender] = peer
    peer.lastSeen = R:Clock()

    if message:sub(1, 2) == "Q|" then
        local revision, index, total, header, payload = parseSnapshot(message, "Q", 3)
        if not revision or header[1] > 999999 or header[2] > 99 or header[3] > 99 then return end
        local assembly = peer.qAssembly
        if not assembly or assembly.rev ~= revision or R:Clock() - assembly.started > 45 then
            assembly = { rev = revision, started = R:Clock(), total = total, parts = {}, header = header }
            peer.qAssembly = assembly
        end
        if assembly.total ~= total or table.concat(assembly.header, ":") ~= table.concat(header, ":") then return end
        assembly.parts[index] = payload
        for i = 1, total do if assembly.parts[i] == nil then return end end
        local ids = {}
        for i = 1, total do
            for id in assembly.parts[i]:gmatch("%d+") do
                id = tonumber(id)
                if id and id >= 1 and id <= 9999999 then ids[id] = true end
            end
        end
        peer.map, peer.x, peer.y, peer.quests = header[1], header[2], header[3], ids
        peer.questSeen = R:Clock()
        peer.qAssembly = nil
        if R.Quests then R.Quests:FindMatches(sender, peer) end
    elseif message:sub(1, 2) == "R|" then
        local revision, index, total, _, payload = parseSnapshot(message, "R", 0)
        if not revision then return end
        local assembly = peer.rAssembly
        if not assembly or assembly.rev ~= revision or R:Clock() - assembly.started > 100 then
            assembly = { rev = revision, started = R:Clock(), total = total, parts = {} }
            peer.rAssembly = assembly
        end
        if assembly.total ~= total then return end
        assembly.parts[index] = payload
        for i = 1, total do if assembly.parts[i] == nil then return end end
        local recipes = {}
        for i = 1, total do
            for item, recipe in assembly.parts[i]:gmatch("(%d+):(%d+)") do
                item, recipe = tonumber(item), tonumber(recipe)
                if item >= 1 and item <= 9999999 and recipe >= 1 and recipe <= 9999999 then
                    recipes[item] = recipe
                end
            end
        end
        peer.recipes = recipes
        peer.recipeSeen = R:Clock()
        peer.rAssembly = nil
    elseif message:sub(1, 2) == "P|" then
        local id, price = message:match("^P|(%d+)|(%d+)$")
        if id and price and R.Market then
            R.Market:Observe(tonumber(id), tonumber(price), sender, false)
        end
    end
end

function N:PrunePeers()
    local now = R:Clock()
    for name, peer in pairs(R.peers) do
        if now - (peer.lastSeen or 0) > 2400 then R.peers[name] = nil end
    end
end
