local _, R = ...
R.Market = { lastSent = {}, lastScan = {} }
local M = R.Market
local MAX_ITEM = 9999999
local MAX_PRICE = 200000000000

function M:Prune(db)
    local now = R:Now()
    local amount = 0
    for itemID, row in pairs(db.prices) do
        if type(row) ~= "table" or type(row.sources) ~= "table" then
            db.prices[itemID] = nil
        else
            local active = false
            for source, obs in pairs(row.sources) do
                if type(obs) ~= "table" or not R:SafeNumber(obs.time, now - 86400, now + 300) or
                    not R:SafeNumber(obs.price, 1, MAX_PRICE) then
                    row.sources[source] = nil
                else
                    active = true
                end
            end
            if not active then db.prices[itemID] = nil else amount = amount + 1 end
        end
    end
    if amount > 700 then
        local ages = {}
        for id, row in pairs(db.prices) do ages[#ages + 1] = { id, row.last or 0 } end
        table.sort(ages, function(a, b) return a[2] > b[2] end)
        for i = 701, #ages do db.prices[ages[i][1]] = nil end
    end
end

function M:Observe(itemID, price, sender, localScan)
    itemID = R:SafeNumber(itemID, 1, MAX_ITEM)
    price = R:SafeNumber(price, 1, MAX_PRICE)
    if not itemID or not price or math.floor(price) ~= price then return end
    local db = R:GuildDB()
    if not db then return end
    local source = R:CleanName(sender)
    local now = R:Now()
    local row = db.prices[itemID]
    if type(row) ~= "table" then row = { sources = {} }; db.prices[itemID] = row end
    row.sources = type(row.sources) == "table" and row.sources or {}
    row.sources[source] = { price = price, time = now }
    row.last = now

    if localScan then
        local previous = self.lastSent[itemID]
        if not previous or R:Clock() - previous.time > 900 or
            math.abs(price - previous.price) > previous.price * 0.08 then
            self.lastSent[itemID] = { price = price, time = R:Clock() }
            R.Net:Queue("P|" .. itemID .. "|" .. math.floor(price), "P:" .. itemID)
        end
    end
end

function M:GetPrice(itemID)
    local db = R:GuildDB()
    if not db or not R:SafeNumber(itemID, 1, MAX_ITEM) then return nil end
    local row = db.prices[itemID]
    if not row or not row.sources then return nil end
    local samples, latest = {}, 0
    for _, obs in pairs(row.sources) do
        if type(obs) == "table" and R:Now() - (obs.time or 0) <= 21600 and
            R:Now() >= (obs.time or 0) and R:SafeNumber(obs.price, 1, MAX_PRICE) then
            samples[#samples + 1] = obs.price
            latest = math.max(latest, obs.time)
        end
    end
    if #samples == 0 then return nil end
    table.sort(samples)
    local mid = math.floor((#samples + 1) / 2)
    local median = (#samples % 2 == 1) and samples[mid] or (samples[mid] + samples[mid + 1]) / 2
    return math.floor(median), #samples, R:Now() - latest
end

function M:ReadCommodity(itemID)
    itemID = R:SafeNumber(itemID, 1, MAX_ITEM)
    if not itemID or not C_AuctionHouse or not C_AuctionHouse.GetNumCommoditySearchResults or not C_AuctionHouse.GetCommoditySearchResultInfo then return end
    local ok, total = pcall(C_AuctionHouse.GetNumCommoditySearchResults, itemID)
    if not ok or not R:SafeNumber(total, 1, 50000) then return end
    local lowest
    for i = 1, math.min(total, 30) do
        local success, info = pcall(C_AuctionHouse.GetCommoditySearchResultInfo, itemID, i)
        if success and type(info) == "table" and R:SafeNumber(info.unitPrice, 1, MAX_PRICE) then
            if not lowest or info.unitPrice < lowest then lowest = info.unitPrice end
        end
    end
    if lowest then self:Observe(itemID, lowest, UnitName("player") or "Self", true) end
end

function M:ReadItem(itemKey)
    if type(itemKey) ~= "table" or not R:SafeNumber(itemKey.itemID, 1, MAX_ITEM) then return end
    -- Variant gear must not be pooled under a shared item ID.
    if (itemKey.itemSuffix or 0) ~= 0 or (itemKey.itemLevel or 0) ~= 0 or (itemKey.battlePetSpeciesID or 0) ~= 0 then return end
    if not C_AuctionHouse or not C_AuctionHouse.GetNumItemSearchResults or not C_AuctionHouse.GetItemSearchResultInfo then return end
    local ok, total = pcall(C_AuctionHouse.GetNumItemSearchResults, itemKey)
    if not ok or not R:SafeNumber(total, 1, 50000) then return end
    local lowest
    for i = 1, math.min(total, 30) do
        local success, info = pcall(C_AuctionHouse.GetItemSearchResultInfo, itemKey, i)
        if success and type(info) == "table" and R:SafeNumber(info.buyoutAmount, 1, MAX_PRICE) and
            R:SafeNumber(info.quantity, 1, 1000000) then
            local price = math.floor(info.buyoutAmount / info.quantity)
            if price > 0 and (not lowest or price < lowest) then lowest = price end
        end
    end
    if lowest then self:Observe(itemKey.itemID, lowest, UnitName("player") or "Self", true) end
end
