local addonName, R = ...
local f = CreateFrame("Frame")

local function SafeRegister(event)
    local ok = pcall(f.RegisterEvent, f, event)
    return ok
end

local function InitialSync()
    if not R:InGuild() then return end
    R.Quests:Broadcast(true)
    if C_Timer and C_Timer.After then
        C_Timer.After(8, function() R.Professions:Broadcast(true) end)
    end
end

local function Start()
    if R.started then return end
    R.started = true
    R:UpdateGuild()
    R.Tooltip:Install()
    if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then
        local ok, status = pcall(C_ChatInfo.RegisterAddonMessagePrefix, R.prefix)
        R.commReady = ok and status ~= false
    end
    if C_Timer and C_Timer.After then C_Timer.After(5, InitialSync) end
    if C_Timer and C_Timer.NewTicker then
        C_Timer.NewTicker(1.5, function() R.Net:SendNext() end)
        C_Timer.NewTicker(60, function()
            R:UpdateGuild()
            R.Quests:Broadcast(false)
            R.Net:PrunePeers()
        end)
        C_Timer.NewTicker(1800, function()
            R.Professions:Broadcast(false)
            local db = R:GuildDB()
            if db then R.Market:Prune(db) end
        end)
    end
end

local function ResetGuild()
    if not R.db then return end
    local before = R.guildKey
    R:UpdateGuild()
    if R.guildKey and R.guildKey ~= before and C_Timer and C_Timer.After then
        C_Timer.After(4, InitialSync)
    end
end

f:SetScript("OnEvent", function(_, event, ...)
    if event == "ADDON_LOADED" then
        if ... == addonName then R:InitializeDB() end
    elseif event == "PLAYER_LOGIN" then
        Start()
    elseif event == "CHAT_MSG_ADDON" then
        local prefix, message, channel, sender = ...
        if prefix == R.prefix and R.commReady then R.Net:Receive(message, channel, sender) end
    elseif event == "PLAYER_GUILD_UPDATE" or event == "GUILD_ROSTER_UPDATE" then
        ResetGuild()
    elseif event == "ZONE_CHANGED_NEW_AREA" or event == "ZONE_CHANGED" or event == "QUEST_LOG_UPDATE" or
        event == "QUEST_ACCEPTED" or event == "QUEST_REMOVED" or event == "QUEST_TURNED_IN" then
        R.Quests:Soon()
    elseif event == "ITEM_SEARCH_RESULTS_UPDATED" or event == "ITEM_SEARCH_RESULTS_ADDED" then
        R.Market:ReadItem(...)
    elseif event == "COMMODITY_SEARCH_RESULTS_UPDATED" or event == "COMMODITY_SEARCH_RESULTS_ADDED" then
        R.Market:ReadCommodity(...)
    elseif event == "TRADE_SKILL_SHOW" or event == "TRADE_SKILL_UPDATE" or event == "TRADE_SKILL_LIST_UPDATE" then
        R.Professions:Soon()
    end
end)

-- Register only events supported by this specific client build.
for _, event in ipairs({
    "ADDON_LOADED", "PLAYER_LOGIN", "CHAT_MSG_ADDON", "PLAYER_GUILD_UPDATE", "GUILD_ROSTER_UPDATE",
    "ZONE_CHANGED_NEW_AREA", "ZONE_CHANGED", "QUEST_LOG_UPDATE", "QUEST_ACCEPTED", "QUEST_REMOVED", "QUEST_TURNED_IN",
    "COMMODITY_SEARCH_RESULTS_UPDATED", "COMMODITY_SEARCH_RESULTS_ADDED", "ITEM_SEARCH_RESULTS_UPDATED", "ITEM_SEARCH_RESULTS_ADDED",
    "TRADE_SKILL_SHOW", "TRADE_SKILL_UPDATE", "TRADE_SKILL_LIST_UPDATE",
}) do SafeRegister(event) end

SLASH_MYCRADAR1 = "/myc"
SLASH_MYCRADAR2 = "/mycradar"
SlashCmdList.MYCRADAR = function(input)
    input = (input or ""):lower():match("^%s*(.-)%s*$")
    if input == "off" then
        R.db.settings.enabled = false
        R.Net:Clear()
        R:Chat("Disabled. /myc on to resume.")
    elseif input == "on" then
        R.db.settings.enabled = true
        R:UpdateGuild()
        InitialSync()
        R:Chat("Enabled.")
    elseif input == "quiet" then
        R.db.settings.alerts = not R.db.settings.alerts
        R:Chat("Quest notifications " .. (R.db.settings.alerts and "on" or "off") .. ".")
    elseif input == "sync" then
        InitialSync()
        R:Chat("Sharing current quest and crafting knowledge.")
    elseif input == "status" or input == "" then
        local peers, priceCount, crafts = 0, 0, 0
        for _, peer in pairs(R.peers) do
            if peer.lastSeen and R:Clock() - peer.lastSeen < 600 then peers = peers + 1 end
        end
        local guildDB = R:GuildDB()
        if guildDB then for _ in pairs(guildDB.prices) do priceCount = priceCount + 1 end end
        for _ in pairs(R.Professions:AllCrafts()) do crafts = crafts + 1 end
        R:Chat("v" .. R.version .. " | " .. (R:IsEnabled() and "ON" or "OFF") ..
            " | Guild peers: " .. peers .. " | AH items observed: " .. priceCount .. " | Your recipes: " .. crafts ..
            " | Outbox: " .. #R.Net.queue)
        R:Chat("Passive mode. /myc quiet, /myc off, /myc on, /myc sync, /myc help")
    else
        R:Chat("Install on your guildmates' clients for shared quests, AH prices and recipes. No setup needed.")
        R:Chat("Commands: /myc status, quiet, off, on, sync")
    end
end
