local addonName, R = ...
R.name = addonName
R.version = "1.0.0"
R.prefix = "MYCRadar1"
R.peers = {}
R.lastToast = -99999
R.alertKeys = {}

function R:Now()
    return (time and time()) or 0
end

function R:Clock()
    return (GetTime and GetTime()) or 0
end

function R:SafeNumber(n, minimum, maximum)
    if issecretvalue and issecretvalue(n) then return nil end
    if type(n) ~= "number" or n ~= n or n == math.huge or n == -math.huge then return nil end
    if n < minimum or n > maximum then return nil end
    return n
end

function R:CleanName(name)
    if issecretvalue and issecretvalue(name) then return "Guildmate" end
    if type(name) ~= "string" then return "Guildmate" end
    return name:gsub("[|\r\n]", ""):sub(1, 40)
end

function R:Chat(msg)
    if DEFAULT_CHAT_FRAME and DEFAULT_CHAT_FRAME.AddMessage then
        DEFAULT_CHAT_FRAME:AddMessage("|cff37d6c0MYC Radar|r  " .. tostring(msg))
    end
end

function R:IsEnabled()
    return self.db and self.db.settings and self.db.settings.enabled ~= false
end

function R:InGuild()
    if not self:IsEnabled() then return false end
    if not IsInGuild or not IsInGuild() then return false end
    return self:UpdateGuild() ~= nil
end

function R:UpdateGuild()
    if not self.db or not self.charDB then return nil end
    local name = GetGuildInfo and GetGuildInfo("player")
    if issecretvalue and issecretvalue(name) then return nil end
    if type(name) ~= "string" or name == "" then return nil end
    local realm = (GetRealmName and GetRealmName()) or ""
    if issecretvalue and issecretvalue(realm) then realm = "" end
    local key = name .. "@" .. tostring(realm)
    if key ~= self.guildKey then
        self.guildKey = key
        self.peers = {}
        self.alertKeys = {}
        if self.Net then self.Net:Clear() end
        if self.Quests then self.Quests:Invalidate() end
        if self.Market then self.Market.lastSent = {} end
    end
    self.db.guilds[key] = self.db.guilds[key] or { prices = {} }
    if type(self.db.guilds[key].prices) ~= "table" then
        self.db.guilds[key].prices = {}
    end
    self.charDB.guilds[key] = self.charDB.guilds[key] or { professions = {} }
    if type(self.charDB.guilds[key].professions) ~= "table" then
        self.charDB.guilds[key].professions = {}
    end
    return key
end

function R:GuildDB()
    if not self:InGuild() then return nil end
    return self.db.guilds[self.guildKey]
end

function R:CharGuildDB()
    if not self:InGuild() then return nil end
    return self.charDB.guilds[self.guildKey]
end

function R:InitializeDB()
    MYCRadarDB = type(MYCRadarDB) == "table" and MYCRadarDB or {}
    MYCRadarCharDB = type(MYCRadarCharDB) == "table" and MYCRadarCharDB or {}
    local db, charDB = MYCRadarDB, MYCRadarCharDB
    db.version = 1
    db.guilds = type(db.guilds) == "table" and db.guilds or {}
    db.settings = type(db.settings) == "table" and db.settings or {}
    if db.settings.enabled == nil then db.settings.enabled = true end
    if db.settings.alerts == nil then db.settings.alerts = true end
    charDB.guilds = type(charDB.guilds) == "table" and charDB.guilds or {}
    self.db = db
    self.charDB = charDB
    self:UpdateGuild()
end

function R:Age(seconds)
    if seconds < 60 then return "now" end
    if seconds < 3600 then return math.floor(seconds / 60) .. "m" end
    return math.floor(seconds / 3600) .. "h"
end

function R:Money(copper)
    copper = math.floor(copper or 0)
    if GetCoinTextureString then return GetCoinTextureString(copper) end
    local gold = math.floor(copper / 10000)
    local silver = math.floor((copper % 10000) / 100)
    local small = copper % 100
    return string.format("%dg %ds %dc", gold, silver, small)
end

function R:Toast(headline, detail, key)
    if not self:IsEnabled() or self.db.settings.alerts == false then return end
    if InCombatLockdown and InCombatLockdown() then return end
    local now = self:Clock()
    if now - self.lastToast < 150 then return end
    if key and self.alertKeys[key] and now - self.alertKeys[key] < 1800 then return end
    if key then self.alertKeys[key] = now end
    self.lastToast = now
    if not self.toastFrame then
        local f = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
        f:SetSize(354, 56)
        f:SetPoint("TOP", UIParent, "TOP", 0, -125)
        f:SetFrameStrata("DIALOG")
        f:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
        f:SetBackdropColor(0.025, 0.08, 0.12, 0.96)
        f:SetBackdropBorderColor(0.16, 0.80, 0.71, 0.90)
        local label = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        label:SetPoint("TOPLEFT", f, "TOPLEFT", 14, -10)
        label:SetPoint("RIGHT", f, "RIGHT", -10, 0)
        label:SetJustifyH("LEFT")
        local sub = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        sub:SetPoint("TOPLEFT", label, "BOTTOMLEFT", 0, -5)
        sub:SetPoint("RIGHT", f, "RIGHT", -10, 0)
        sub:SetJustifyH("LEFT")
        f.label, f.sub = label, sub
        self.toastFrame = f
    end
    self.toastFrame.label:SetText(headline)
    self.toastFrame.sub:SetText(detail)
    self.toastFrame:Show()
    self.toastSerial = (self.toastSerial or 0) + 1
    local serial = self.toastSerial
    if C_Timer and C_Timer.After then
        C_Timer.After(7, function()
            if self.toastSerial == serial and self.toastFrame then self.toastFrame:Hide() end
        end)
    end
end
