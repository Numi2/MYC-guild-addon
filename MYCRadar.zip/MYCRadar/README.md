# MYC Radar 1.0.0 — Murloch Yact Club

Passive guild assistance for **World of Warcraft: Forever** (interface **16001**, game **1.60.1**).

## Install (one time)

1. Completely exit World of Warcraft: Forever.
2. Extract this ZIP and copy the **MYCRadar** folder directly into:
   `World of Warcraft/_forever_/Interface/AddOns/`
3. Make sure this exact file exists:
   `_forever_/Interface/AddOns/MYCRadar/MYCRadar.toc`
4. Launch Forever and enable **MYC Radar** in the character-select AddOns menu if needed.
5. Share the same ZIP with guildmates. No configuration or account is required.

**After installing, just play normally.** The addon does not need a minimap button, a login, a companion application or a manual scan. There is no mandatory setup step.

## What it does automatically

* **Shared quest radar:** Detects guildmates running the same *unfinished* quest in the same map area. It gives at most one quiet toast every 2.5 minutes and suppresses repeat matches. Position is shared as a coarse 10×10 map tile; when coordinates are unavailable, the match falls back to the same in-game map. Exact positions, quest objectives and GPS are not transmitted.
* **Guild Auction House observations:** When you naturally search at the Auction House, captures the lowest visible unit buyout for that item and relays a compact observation to online guildmates using the addon. Item tooltips show the median **observed** price from distinct recent guild members, the newest observation's age and how many sources contributed. Data is neither live across all listings nor an automated whole-AH scan; no extra auction queries are performed. Observations older than six hours are not shown.
* **Guild crafting network:** When you naturally open a profession window, remembers recipes you *actually know* that produce items and shares them. Hover an item to see which online guildmates the addon has recently heard from can craft it. Enchants that do not create an item are not listed. Guildmates must also install the addon and open their profession windows at least once to be indexed.

Communication runs exclusively over Blizzard's **GUILD addon-message channel**. The addon keeps outgoing messages below 255 bytes and transmits at most one message every 1.5 seconds. Restrictions or throttles imposed by Forever can delay/prevent synchronization, particularly in instanced content. Players not using MYC Radar cannot be matched or contribute observations/recipes.

## Optional commands

| Command | Meaning |
|---|---|
| `/myc` or `/myc status` | Show one-line status and network metrics |
| `/myc quiet` | Toggle shared-quest popup notifications (sharing continues) |
| `/myc off` | Stop all MYC Radar processing and outgoing sharing |
| `/myc on` | Re-enable |
| `/myc sync` | Send available quest/recipe snapshots sooner (not normally needed) |
| `/myc help` | Show help |

## Privacy and scope

Installing the addon enables guild-only sharing of **current unfinished quest IDs, coarse in-game map location, recipes for craftable item outputs, and auction price observations**. No chat text, bag contents, total gold, combat information, screenshots or external network traffic is recorded or transmitted. Local last-observed price samples are kept as SavedVariables for up to 24 hours and auto-pruned; per-guild data is stored separately. Incoming guildmate quest/recipe data remains in memory and expires. The addon never invites, buys, sells, crafts or executes actions on the player's behalf.

## Compatibility and verification

* Target: **WoW Forever 1.60.1**, not Classic Era or Anniversary, with `.toc` interface **16001**.
* Uses modern Blizzard APIs for quest logs, maps, guild addon messages, auction searches, tradeskills, and item tooltips. Restricted/unknown events are registered defensively.
* Offline verification: Lua syntax passed with `texluac`; mock-client tests covered startup, quest matching, message transport and fragmentation, rate limiting, AH observations, recipe filtering and tooltip formatting (34 assertions).
* **Not yet verified inside a running Forever client.** If Blizzard alters an API, some features may be unavailable until updated. To show any Lua errors while testing, type `/console scriptErrors 1`, then `/reload`.

Version: 1.0.0. No bundled external libraries or executables. Source code is included in this installable package.
